System.register(["./typescript-legacy.ceea8b8a.js","./MonacoEditor-legacy.fb540691.js","./antdv-legacy.7bd4694a.js","./index-legacy.fd6ad50b.js","./article-legacy.3ab0b755.js","./_plugin-vue_export-helper-legacy.649209c3.js"],(function(e,t){"use strict";var i,s;return{setters:[function(e){i=e.conf,s=e.language},function(){},function(){},function(){},function(){},function(){}],execute:function(){
/*!-----------------------------------------------------------------------------
       * Copyright (c) Microsoft Corporation. All rights reserved.
       * Version: 0.34.1(547870b6881302c5b4ff32173c16d06009e3588f)
       * Released under the MIT license
       * https://github.com/microsoft/monaco-editor/blob/main/LICENSE.txt
       *-----------------------------------------------------------------------------*/
e("conf",i),e("language",{defaultToken:"invalid",tokenPostfix:".js",keywords:["break","case","catch","class","continue","const","constructor","debugger","default","delete","do","else","export","extends","false","finally","for","from","function","get","if","import","in","instanceof","let","new","null","return","set","super","switch","symbol","this","throw","true","try","typeof","undefined","var","void","while","with","yield","async","await","of"],typeKeywords:[],operators:s.operators,symbols:s.symbols,escapes:s.escapes,digits:s.digits,octaldigits:s.octaldigits,binarydigits:s.binarydigits,hexdigits:s.hexdigits,regexpctl:s.regexpctl,regexpesc:s.regexpesc,tokenizer:s.tokenizer})}}}));
